<?php
//NOTE See autoload for details
require '../autoload.php';

$router = new Router();
echo $router->render();