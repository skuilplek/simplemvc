<?php

define('DATABASE_SERVER','localhost');
define('DATABASE_USERNAME','root');
define('DATABASE_PASSWORD','sql@root');
define('DATABASE_NAME','roomraccoon');